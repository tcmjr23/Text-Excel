package textExcel;

public class ValueCell extends RealCell implements Cell{ 
	
	public int value;
	
	//constructor
	public ValueCell(double value) {
		super(value+"");
		this.value = (int)value;
	}

	//returns the value as a double
	public double getDoubleValue() {
		return Double.parseDouble(super.value);   
	}
	
	//returns an abbreviated version of the value (10 characters long)
	public String abbreviatedCellText() {
		String abbText = "" + super.value;
		
		if(abbText.length()>10) {
			return abbText.substring(0,10);
		}
		else {
			while(abbText.length()<10) {
				abbText+=" ";
			}
			abbText+="";
			return abbText;
		}
		
	}
	
	//returns the full value
	public String fullCellText() {
		return "" + super.value;
	}
}
