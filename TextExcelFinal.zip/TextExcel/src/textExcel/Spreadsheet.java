package textExcel;
import java.lang.*;
/*Troy Mosqueda
 * February 22, 2023
 * class definition for Spreadsheet
 */

// Update this file with your own code.

public class Spreadsheet implements Grid
{
	Cell[][] arr;
	
	
	//constructor
	public Spreadsheet() {
		arr = new Cell[20][12];
		for(int i = 0;i<20;i++) {
			for(int j = 0;j<12;j++) {
				Cell cell = new EmptyCell(); 
				arr[i][j] = cell; 
			}
		}
	}
	
	//takes in commands and processes them
	public String processCommand(String command)
	{	
		String[] split = command.split(" ",3);
		
		//test
		for(int i = 0; i < split.length;i++) {
			System.out.println("split" + split[i]); 
		}
		
		
		if(split.length==1) {	
			if(split[0].toLowerCase().equals("clear")) {
				clearGridText();
			}
			else{
				Location loc = new SpreadsheetLocation(split[0].toUpperCase());
				return arr[loc.getRow()][loc.getCol()].fullCellText();
			}
		}	
		else if(split.length==2) {
			Location loc = new SpreadsheetLocation(split[1].toUpperCase());
			arr[loc.getRow()][loc.getCol()]=new EmptyCell();
		}else {
			SpreadsheetLocation loc = new SpreadsheetLocation(split[0].toUpperCase());
			System.out.println("PROCESS LOC : " + loc.getRow() + "  " + loc.getCol());
			String value = split[2];
			if(value.startsWith("\"")) {
				while(value.indexOf("\"")>=0) {
					value = value.substring(split[2].indexOf("\"")+1,split[2].indexOf("\"",1));
				} 
				System.out.println(split[2]); //test
				arr[loc.getRow()][loc.getCol()]=new TextCell(value);
			}
			else if(split[2].indexOf("%")>=0){
				arr[loc.getRow()][loc.getCol()]=new PercentCell(Double.parseDouble(split[2].substring(0,split[2].indexOf("%"))));
			}
			else if(split[2].indexOf("(")>=0) {
				arr[loc.getRow()][loc.getCol()]=new FormulaCell(split[2]);
				System.out.println("FORMULACELL CREATED: " + split[2]);
				System.out.println("form val: "+ loc.getRow() + " " + loc.getCol());
			}else {
				arr[loc.getRow()][loc.getCol()]=new ValueCell(Double.parseDouble(split[2]));
			}
		}	
		return getGridText();
	}

	//returns # of rows of the instantiated spreadsheet
	public int getRows()
	{
		return 20;
	}

	//returns the # of columns of the instantiated spreadsheet
	public int getCols()
	{
		return 12;
	}

	//returns the cell in the location passed
	public Cell getCell(Location loc) 
	{
		
		System.out.println("LOC GETCELL: "+loc.getRow());
		System.out.println("LOC GETCELL: "+loc.getCol());
		int column = loc.getCol();
		char row = (char)loc.getRow();
		String name = row+""+column;
		/*SpreadsheetLocation cool = new SpreadsheetLocation(name);//////////////////////
		Cell temp = new RealCell(arr[row][column].fullCellText());*/
	
		return arr[loc.getRow()][loc.getCol()];  //ch5 testing a (Cell) cast
		
	}

	//returns the grid text with values represented
	public String getGridText()
	{
		
		String ret = "   |";
		for (char let=65; let<77;let++) {
			ret+=let + "         |";
		}
		ret+="\n";
		for(int i = 1; i<=getRows(); i++) {
			ret+= i + " ";
			if(i<10) {
				ret+=" ";
			}
			ret+="|";
			for(int j = 0; j<this.getCols();j++) {
				ret+= arr[i-1][j].abbreviatedCellText()+"|";
			}		
			
			ret+="\n";
		}
		return ret;
	}

	//clears the text within the grid and resets them to empty cells
	public void clearGridText() {
		this.arr = new Cell[20][12];
		for(int i = 0;i<20;i++) {
			for(int j = 0;j<12;j++) {
				Cell cool = new EmptyCell(); 
				arr[i][j] = cool;
			}
		}
	}
}
