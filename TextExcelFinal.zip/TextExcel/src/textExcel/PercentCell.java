package textExcel;

public class PercentCell extends RealCell{
	
	public double value;
	
	//constructor
	public PercentCell(double value) {
		super(value+"");
		this.value = value;
		// TODO Auto-generated constructor stub
	}
	
	//returns the value as a double
	public double getDoubleValue() {
		return Double.parseDouble(super.value);   //check if cast is redundant
	}
	
	//returns truncated value
	public String abbreviatedCellText() {
		String abbText = "" + (int)value + "%";
		
		if(abbText.length()>10) {
			return abbText.substring(0,10);
		}
		else {
			while(abbText.length()<10) {
				abbText+=" ";
			}
			abbText+="";
			return abbText;
		}
	}
	
	//returns full value
	public String fullCellText() {
		return "" + super.value + "%";
	}
}
