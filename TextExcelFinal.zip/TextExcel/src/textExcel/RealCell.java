package textExcel;
//extends spreadsheet ijmplements Cell
public class RealCell extends Spreadsheet implements Cell{     //extends spreadsheet 

	public String value; 
	
	//constructor
	public RealCell(String value) {
		this.value = value; 
	}
	
	public String abbreviatedCellText() {
		return null;
	}

	//returns full text
	public String fullCellText() {
		
		return "" + this.value;
	}
	
	//returns the value as a double
	public double getDoubleValue() {

	    return 5;
	}

}
