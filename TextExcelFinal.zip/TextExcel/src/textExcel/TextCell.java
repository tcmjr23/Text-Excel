package textExcel;

public class TextCell extends RealCell implements Cell{

	public String text;
	public String abbText;
	
	public TextCell(String stuff) {
		super(stuff);
		abbText = stuff;
	}
	@Override
	public String abbreviatedCellText() {
		// TODO Auto-generated method stub
		if(abbText.length()>10) {
			return abbText.substring(0,10);
		}
		else {
			while(abbText.length()<10) {
				abbText+=" ";
			}
			abbText+="";
			return abbText;
		}
//		
	}

	@Override
	public String fullCellText() {
		// TODO Auto-generated method stub
		return "\"" + text + "\"";
		
	}

}
