package textExcel;

import java.util.ArrayList;

public class FormulaCell extends RealCell implements Cell{
	
	//stores initial formula (not result)
	public String value;
	
	//constructor 
	public FormulaCell(String value) {
		super(value);
		this.value = value;
		
	}
		
	//calculates the formula and returns the result, also implements PEMDAS as well as avg and sum methods 
	public double getDoubleValue() {
		String[] eq = value.split(" ");
		System.out.println("SUMMM: eq[3]" + eq[1]);
		if(eq[1].indexOf("AVG")>=0) {
			return AVG(eq);
		}
				
		if(eq[1].indexOf("SUM")>=0) {
			return SUM(eq);
		
		}
		//EXTRA CREDIT ATTEMPT
		ArrayList<String> pemdas= new ArrayList<String>();
		for (int k = 0; k < eq.length; k++) {
			if(isNumeric(eq[k])){
				pemdas.add(eq[k]);
			}else if(!isNumeric(eq[k]) && eq[k].indexOf("-")>0) {
				ArrayList<String> method= new ArrayList<String>();
				if(eq[k].indexOf("SUM")>0) {
					for (int i = eq[k].indexOf("AVG")-1; i<eq.length;i++) {
						method.add(eq[i]);
					}
				}
				
				
			
			
			}else if(!isNumeric(eq[k]) && eq[k].length()>1 && (!eq[k].equals("SUM")) && (!eq[k].equals("AVG"))) {
				System.out.println(" eqk: "+eq[k]);
				
				
				
				
				
				Location loc = new SpreadsheetLocation(eq[k].toUpperCase()); 
				Cell cell = getCell(loc); 
				System.out.println(" FC : "+loc.getRow() + " | " + loc.getCol());
				RealCell newCell = (RealCell) cell;
				double val =  newCell.getDoubleValue();  
				pemdas.add(val+"");
			}else {
				pemdas.add(eq[k]);
			}
			
			System.out.print("testpemdas" + pemdas + "test");
			System.out.println();
		}
		
		
		
		
		
		
		
		while(pemdas.size()>3) {
			for(int j = 0; j < pemdas.size();j++) { 
				if(pemdas.get(j).equals("*")){
					System.out.print(pemdas + ": *    ");
					double temp = Double.parseDouble(pemdas.get(j-1))*Double.parseDouble(pemdas.get(j+1)); //should one be +1????
					pemdas.remove(j);
					pemdas.remove(j);
					pemdas.set(j-1, temp+"");
					j--;
					System.out.println(pemdas + ": *    ");					
				}
			}
			for( int k = 0; k < pemdas.size();k++) { // ( 5 + 5 * 5 / 5)
				// ( 3 * 6 / 9 + 5 / 2) =  18  
				if(pemdas.get(k).equals("/")) {
					System.out.print(pemdas + ": /    ");
					double temp = Double.parseDouble(pemdas.get(k-1))/Double.parseDouble(pemdas.get(k+1));
					pemdas.remove(k);
					pemdas.remove(k);
					pemdas.set(k-1, temp+"");
					k--;
					System.out.println(pemdas + ": /    ");
				}
			}
			for( int k = 0; k < pemdas.size();k++) {
				if(pemdas.get(k).equals("+")){
					System.out.print(pemdas + ": +    ");
					double temp = Double.parseDouble(pemdas.get(k-1))+Double.parseDouble(pemdas.get(k+1));
					pemdas.remove(k);
					pemdas.remove(k);
					pemdas.set(k-1, temp+"");
					k--;
					System.out.println(pemdas + ": +    ");
				}
			}
			for( int k = 0; k < pemdas.size();k++) {
				
				if(pemdas.get(k).equals("-")){
					System.out.print(pemdas + ": -    ");
					double temp = Double.parseDouble(pemdas.get(k-1))-Double.parseDouble(pemdas.get(k+1));
					pemdas.remove(k);
					pemdas.remove(k);
					pemdas.set(k-1, temp+"");
					k--;
					System.out.println(pemdas + ": -");
				}
			}
		}
			System.out.println("AAAAAAAAAAAAAAAA" + pemdas.get(1));
		return Double.parseDouble(pemdas.get(1));
	}				
			
	//abbreviates the result of getDoubleValue + returns it
	public String abbreviatedCellText() {
		String abbText = "" + this.getDoubleValue();
		
		if(abbText.length()>10) {
			return abbText.substring(0,10);
		}
		else {
			while(abbText.length()<10) {
				abbText+=" ";
			}
			abbText+="";
			return abbText;
		}
		
	}
	
	
	//returns the full cell text/the initial formula
	public String fullCellText() {
		return "" + super.value;
	}
	
	public static boolean isNumeric(String str) { 
		  try {  
		    Double.parseDouble(str);  
		    return true;
		  } catch(NumberFormatException e){  
		    return false;  
		  }  
	}
	
	public double SUM(String[] eq) {
		double running = 0;
		int startRow = Integer.parseInt(eq[2].substring(1,eq[2].indexOf("-")));  //65
		int endRow = Integer.parseInt(eq[2].substring((eq[2].indexOf("-"))+2));//68
		System.out.println("sum method: " + eq[2]);
		int startCol = (eq[2].charAt(0))-65; 
		
		String s = eq[2].toUpperCase();
		int begin = s.charAt(s.indexOf("-")+1)-65;  //C
		System.out.println("EBEGIN SUM : " + begin);
		int endCol = s.charAt(begin);
		
		
		
		System.out.println("START ROW: " + startRow);
		
		for(int ine = startRow+1; ine <= endRow; ine++) {
			for(int j = startCol; j <=endCol; j++) {
				char lo;
				int m = ine + 16;
				lo =(char)((m) + '0');
				String a = lo+"";
				System.out.println("SUM SPREADSHEET LOCATION: " + ine + " " +j+ " " + lo);
				String jay = ""+j;
				String cellName = lo + "" + j; 
				Location loc = new SpreadsheetLocation(cellName); //1
 
				RealCell newCell = (RealCell) getCell(loc);   //RealCell newCell = (RealCell) here;
				double temp =  newCell.getDoubleValue();
				running+= temp;
			}
		}
		return running;
	}
	public double AVG(String[] eq) {
		int denominator = 0;
		int startRow = Integer.parseInt(eq[2].substring(1,eq[2].indexOf("-")));  //65
		int endRow = Integer.parseInt(eq[2].substring((eq[2].indexOf("-"))+2));//68
		System.out.println("sum method: " + eq[2]);
		int startCol = (eq[2].charAt(0))-65; 
		
		String s = eq[2].toUpperCase();
		System.out.println("EEEESSSSS" + s);
		int begin = s.charAt(s.indexOf("-")+1)-65;  //C
		System.out.println("BEGIN  " + begin);
		int endCol = s.charAt(begin);
		System.out.println("ENDCOL : " + endCol);
		for(int i = startRow; i <= endRow; i++) {
			for(int j = startCol; j <=endCol; j++) {
				denominator+=1;
			}
		}return SUM(eq)/denominator;
	}
}


