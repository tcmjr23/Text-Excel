package textExcel;

import java.io.FileNotFoundException;
import java.util.Scanner;

// Update this file with your own code.

public class TextExcel
{

	public static void main(String[] args)
	{
		Spreadsheet sheetspread = new Spreadsheet();
	    // Add your command loop here
		Scanner input = new Scanner(System.in);
		String user = "A1";
		
		//TEMPORARY
        
        
        user = "";
		while(!user.equals("quit")) { 
			System.out.println("Command: ");
			user = input.nextLine();
			String pC =sheetspread.processCommand(user);  
			System.out.println(pC);

			
    	}
	}
}


