package textExcel;

import java.util.Scanner;

/*Troy Mosqueda
 * February 22, 2023
 */


public class SpreadsheetLocation implements Location
{
	//instance variables 
	public String cellName;
	public int row;
	public int col;
	
	//Constructor
    public SpreadsheetLocation(String cellName)
    {
    	this.cellName = cellName.toUpperCase();
    	this.col = cellName.charAt(0);
    	if(col>64) {
    		this.col = col-65; // - 65
    	}
    	this.row = Integer.parseInt(cellName.substring(1,cellName.length()))-1 ;
    	System.out.println("AA" + this.row + " by " + this.col);
 		
	}
  
    //returns the row value
    public int getRow()
    {
        
        return row;
    }

    //returns the column value
    public int getCol()
    {
        // TODO Auto-generated method stub
        return col;
    	
    }
    
}
